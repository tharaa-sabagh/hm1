package tr4;



import java.io.FileNotFoundException;

import java.io.PrintWriter;

import java.io.UnsupportedEncodingException;

import java.util.Scanner;  // Import the Scanner class



public class htmlfile {

	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {

	    Scanner scan = new Scanner(System.in);

	    System.out.println("Enter a number");



	    int num = scan.nextInt();  // Read user input

	    int count=0;

	PrintWriter writer = new PrintWriter("the-file-name.html", "UTF-8");

	writer.println("<html>\r\n" + 

			"\r\n" + 

			"<head>\r\n" + 

			"\r\n" + 

			"<body>");

	for (int i = 0; i < num; i++) {

		if(count%3==0)

			writer.println("<div style=\"background-color: blue;\r\n" + 

					"                width: " +100/num + "%;\r\n" + // divide the screen to n areas

					"                height: 100%;\r\n" + 

					"                float :right;\">\r\n" + 

					"    </div>");

		if(count%3==1)

			writer.println("<div style=\"background-color: green;\r\n" + 

					"                width: " +100/num + "%;\r\n" + 

					"                height: 100%;\r\n" + 

					"                float :right;\">\r\n" + 

					"    </div>");

		if(count%3==2)

			writer.println("<div style=\"background-color: red;\r\n" + 

					"                width: " +100/num + "%;\r\n" + 

					"                height: 100%;\r\n" + 

					"                float :right;\">\r\n" + 

					"    </div>");

		count++;

	}

	writer.println("</body>\r\n" + 

			"</head>\r\n" + 

			"\r\n" + 

			"</html>");

	writer.close();

	scan.close();

  }

}





  